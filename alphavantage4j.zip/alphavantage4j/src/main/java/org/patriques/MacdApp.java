package org.patriques;

import java.awt.Color;
import java.util.Calendar;
import java.util.List;
import java.util.Map;

import javax.swing.JFrame;
import javax.swing.WindowConstants;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.XYPlot;
import org.jfree.data.time.Day;
import org.jfree.data.time.RegularTimePeriod;
import org.jfree.data.time.TimeSeries;
import org.jfree.data.time.TimeSeriesCollection;
import org.jfree.data.xy.XYDataset;
import org.patriques.input.technicalindicators.Interval;
import org.patriques.input.technicalindicators.SeriesType;
import org.patriques.input.technicalindicators.TimePeriod;
import org.patriques.input.timeseries.OutputSize;
import org.patriques.output.AlphaVantageException;
import org.patriques.output.technicalindicators.MACD;
import org.patriques.output.technicalindicators.SMA;
import org.patriques.output.technicalindicators.data.MACDData;
import org.patriques.output.timeseries.Daily;
import org.patriques.output.timeseries.IntraDay;
import org.patriques.output.timeseries.data.StockData;

public class MacdApp extends JFrame {

	private String apiKey = "1HQHBSU9GMCSSSRD";
	private int timeout = 3000;
	private AlphaVantageConnector apiConnector = new AlphaVantageConnector(apiKey, timeout);
	private TechnicalIndicators technicalIndicators = new TechnicalIndicators(apiConnector);

	private XYDataset createDataset() {
		XYDataset dataset = new TimeSeriesCollection();
		try {
			MACD response = technicalIndicators.macd("TCS", Interval.DAILY, TimePeriod.of(timeout), SeriesType.OPEN,
					null, null, null);
			Map<String, String> metaData = response.getMetaData();
			System.out.println("Symbol: " + metaData.get("1: Symbol"));
			System.out.println("Indicator: " + metaData.get("2: Indicator"));

			List<MACDData> macdData = response.getData();
			TimeSeries series1 = new TimeSeries("MACD");
			TimeSeries series2 = new TimeSeries("MACD Hist");
			TimeSeries series3 = new TimeSeries("MACD Signal");

			for (int i = 0; i < 100; i++) {
				MACDData data = macdData.get(i);
				System.out.println("date:           " + data.getDateTime());
				System.out.println("MACD Histogram: " + data.getHist());
				System.out.println("MACD Signal:    " + data.getSignal());
				System.out.println("MACD:           " + data.getMacd());
				Day d = new Day(data.getDateTime().getDayOfMonth(), data.getDateTime().getMonthValue(),
						data.getDateTime().getYear());
				series1.add(d, data.getMacd());
				series2.add(d, data.getHist());
				series3.add(d, data.getSignal());
			}
			((TimeSeriesCollection) dataset).addSeries(series1);
			((TimeSeriesCollection) dataset).addSeries(series2);
			((TimeSeriesCollection) dataset).addSeries(series3);
		} catch (AlphaVantageException e) {
			System.out.println("something went wrong");
		}

		finally {
			return dataset;
		}

	}

	public static void main(String[] args) {

		MacdApp macdChart = new MacdApp();
		macdChart.setSize(1000, 500);
		macdChart.setLocationRelativeTo(null);
		macdChart.setVisible(true);
		macdChart.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);

		// Changes background color
	}

	MacdApp() {
		XYDataset dataset = createDataset();
		JFreeChart chart = ChartFactory.createTimeSeriesChart("MACD", // Chart
				"Date", // X-Axis Label
				"Number", // Y-Axis Label
				dataset, true, true, true);
		XYPlot plot = (XYPlot) chart.getPlot();
		plot.setBackgroundPaint(new Color(255, 228, 196));
		
		ChartPanel panel = new ChartPanel(chart);
		setContentPane(panel);

	}
}