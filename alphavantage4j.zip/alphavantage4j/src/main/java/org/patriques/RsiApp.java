package org.patriques;

import java.awt.Color;
import java.util.Calendar;
import java.util.List;
import java.util.Map;

import javax.swing.JFrame;
import javax.swing.WindowConstants;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.XYPlot;
import org.jfree.data.time.Day;
import org.jfree.data.time.RegularTimePeriod;
import org.jfree.data.time.TimeSeries;
import org.jfree.data.time.TimeSeriesCollection;
import org.jfree.data.xy.XYDataset;
import org.patriques.input.technicalindicators.Interval;
import org.patriques.input.technicalindicators.SeriesType;
import org.patriques.input.technicalindicators.TimePeriod;
import org.patriques.input.timeseries.OutputSize;
import org.patriques.output.AlphaVantageException;
import org.patriques.output.technicalindicators.MACD;
import org.patriques.output.technicalindicators.RSI;
import org.patriques.output.technicalindicators.SMA;
import org.patriques.output.technicalindicators.data.IndicatorData;
import org.patriques.output.technicalindicators.data.MACDData;
import org.patriques.output.timeseries.Daily;
import org.patriques.output.timeseries.DailyAdjusted;
import org.patriques.output.timeseries.IntraDay;
import org.patriques.output.timeseries.data.StockData;

public class RsiApp extends JFrame {

	private String apiKey = "1HQHBSU9GMCSSSRD";
	private int timeout = 3000;
	private AlphaVantageConnector apiConnector = new AlphaVantageConnector(apiKey, timeout);
	private TechnicalIndicators technicalIndicators = new TechnicalIndicators(apiConnector);

	private XYDataset createDataset() {
		XYDataset dataset = new TimeSeriesCollection();
		try {
			RSI response = technicalIndicators.rsi("TCS", Interval.DAILY, TimePeriod.of(30), SeriesType.CLOSE);
			org.patriques.TimeSeries main = new org.patriques.TimeSeries(apiConnector);
			DailyAdjusted dmain =main.dailyAdjusted("TCS");
			List<StockData> listMain = dmain.getStockData();
			Map<String, String> metaData = response.getMetaData();
			System.out.println("Symbol: " + metaData.get("1: Symbol"));
			System.out.println("Indicator: " + metaData.get("2: Indicator"));

			List<IndicatorData> rsiData = response.getData();
			TimeSeries series = new TimeSeries("RSI");
			TimeSeries mainSeries = new TimeSeries("Stock");
			for (int i = 0; i < 50; i++) {
				IndicatorData data = rsiData.get(i);
				StockData stockData = listMain.get(i);
				System.out.println("date:           " + data.getDateTime());
				System.out.println("RSI" + data.getData());
				Day d = new Day(data.getDateTime().getDayOfMonth(), data.getDateTime().getMonthValue(),
						data.getDateTime().getYear());
				series.add(d, data.getData());
				mainSeries.add(d, stockData.getAdjustedClose());
				System.out.println("date:           " + stockData.getDateTime());
				System.out.println("Stock" + stockData.getAdjustedClose());
			}
			((TimeSeriesCollection) dataset).addSeries(series);
			//((TimeSeriesCollection) dataset).addSeries(mainSeries);
		} catch (AlphaVantageException e) {
			System.out.println("something went wrong");
		}

		finally {
			return dataset;
		}

	}

	public static void main(String[] args) {

		RsiApp rsiChart = new RsiApp();
		rsiChart.setSize(1000, 500);
		rsiChart.setLocationRelativeTo(null);
		rsiChart.setVisible(true);
		rsiChart.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);

		// Changes background color
	}

	RsiApp() {
		XYDataset dataset = createDataset();
		JFreeChart chart = ChartFactory.createTimeSeriesChart("RSI", // Chart
				"Date", // X-Axis Label
				"Number", // Y-Axis Label
				dataset, true, true, true);
		XYPlot plot = (XYPlot) chart.getPlot();
		plot.setBackgroundPaint(new Color(255, 228, 196));
		
		ChartPanel panel = new ChartPanel(chart);
		setContentPane(panel);

	}
}